import os
import numpy as np
import pandas as pd
from pandas_profiling import ProfileReport
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from glob import glob
sns.set_theme()

d = './data/'                                    # data directory
p = './profiling/'                               # profiling directory
os.chdir(d)
files = glob('*')
os.chdir('../')
flist = [f[0:-4] for f in files]
for f in flist:
    data = pd.read_csv(d+f+'.csv',quotechar='"')     # read with quotechar
    data = data.iloc[::-1].reset_index()             # reverse order
    data['TimeStamp'] = pd.to_datetime(data['TimeStamp']) # to datetime
    n = len(data)                                    # add ROP
    x = np.zeros(n)*np.nan
    y = [True]*n
    for i in range(1,n):
        x[i] = (data['TimeStamp'][i]-data['TimeStamp'][i-1]).total_seconds()
        y[i] = True if data['Rod Count'][i]>data['Rod Count'][i-1] else False
    x[0] = np.mean(x[1:3]) # average of 2 and 3 for 1st time point only
    data['ROP (ft/min)'] = np.array(y)*60.0*10.0/x
    data['Drill'] = y
    data = data[data['Drill']]                       # Remove all but forward drill
    #data = data[data['ROP (ft/min)']<4]             # Keep data with ROP < 4
    data['Time'] = data['TimeStamp']                 # Time last
    del data['TimeStamp']                            # remove TimeStamp
    del data['index']                                # remove index
    col=data.columns

    file = p+f+'.html'
    if not os.path.isfile(file):
        prof = ProfileReport(data)
        prof.to_file(output_file=file)
    else:
        print('Delete file '+file+' to regenerate profiling report')
        
    plt.figure(figsize=(12,10))
    n = len(col)-1
    nc = 3
    nr = int(np.ceil(n/nc))
    for i,c in enumerate(col[0:-1]):
        ax = plt.subplot(nr,nc,i+1)
        plt.plot(data[c],'b.',label=c)
        plt.xlabel('Rod Sequence')
        plt.legend()
    plt.savefig('./figures/Time_'+f+'.png')

    plt.figure(figsize=(12,10))
    n = len(col)-1
    nc = 3
    nr = int(np.ceil(n/nc))
    for i,c in enumerate(col[0:-1]):
        ax = plt.subplot(nr,nc,i+1)
        plt.plot(data[c],data['Rod Count'],'b.',label=c)
        plt.ylabel('Rod Count')
        plt.legend()
    plt.savefig('./figures/Rod_'+f+'.png')

    plt.figure(figsize=(12,10))
    n = len(col)-1
    nc = 3
    nr = int(np.ceil(n/nc))
    for i,c in enumerate(col[0:-1]):
        ax = plt.subplot(nr,nc,i+1)
        plt.plot(data[c],data['ROP (ft/min)'],'b.',label=c)
        plt.ylabel('ROP (ft/min)')
        plt.legend()
    plt.savefig('./figures/ROP_'+f+'.png')
